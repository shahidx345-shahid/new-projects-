from django.db import models

class Registration(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    company = models.CharField(max_length=255)
    country = models.CharField(max_length=100)
    job_role = models.CharField(max_length=100)
    agreed_to_terms = models.BooleanField(default=False)  # ✅ Must be BooleanField

    def __str__(self):
        return self.email

