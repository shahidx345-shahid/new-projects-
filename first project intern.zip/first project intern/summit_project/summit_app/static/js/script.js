function openModal() {
    document.getElementById("registerModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("registerModal").style.display = "none";
}

// Close modal if clicking outside modal content
window.onclick = function(event) {
    let modal = document.getElementById("registerModal");
    if (event.target === modal) {
        modal.style.display = "none";
    }
};
