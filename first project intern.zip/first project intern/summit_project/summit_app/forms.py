from django import forms
from .models import Registration

class RegistrationForm(forms.ModelForm):
    agreed_to_terms = forms.BooleanField(required=True)  # Ensure this exists

    class Meta:
        model = Registration
        fields = ['first_name', 'last_name', 'email', 'company', 'country', 'job_role', 'agreed_to_terms']



