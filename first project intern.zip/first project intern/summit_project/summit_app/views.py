from django.shortcuts import render, redirect
from .forms import RegistrationForm
from django.contrib.auth.models import User


def home(request):
    form = RegistrationForm()
    return render(request, 'summit_app/index.html', {'form': form})

def register(request):
    if request.method == "POST":
       

        form = RegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')  
  
           

    else:
        form = RegistrationForm()
    
    return render(request, 'summit_app/index.html', {'form': form})



def success(request):
    return render(request, 'summit_app/success.html')
