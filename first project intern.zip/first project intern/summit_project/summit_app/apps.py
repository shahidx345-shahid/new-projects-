from django.apps import AppConfig


class SummitAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'summit_app'
